--------------------------------------------
Spellbook Manager version 5.0 for Windows
--------------------------------------------
This program is being offered free of charge for
non-commercial use only.  The only "payment" requested 
is an e-mail message to the author if you find 
Spellbook Manager useful.   Those who do will also be
directly notified of upgrades or enhancements.
Thank-you!

KevenSimmons@HisEmail.com
http://members.tripod.com/~KevenSimmons/index.html
(or mirror site at http://www.norwich.net/simmonsk/index.html )

New to This Version:
-----------------------------------------------
In addition to fixing a few minor bugs, this version adds a
browse filter capability to the Master Spell List to help you find 
the spells you want when building a spellbook.  Also added is the 
ability to mark spells in a spellbook as memorized.


Zip File contents:
---------------------
    SpellbookManager.exe
    SpellbookManager.hlp
    Master.dat
    Tome.dat
    ReadMe.txt


To intstall
-------------------------
Create a new directory/folder to hold the program, 
and extract the contents of the Zip archive into it.
For Help using the Application, open the SpellbookManager.hlp 
file.


Compatibility Notes:
-----------------------------------------------
Spellbooks created with Spellbook Manager v3.x are upward 
compatible with v4.x and v5.x but once saved cannot be opened
again with a prior verion without the loss of some data.